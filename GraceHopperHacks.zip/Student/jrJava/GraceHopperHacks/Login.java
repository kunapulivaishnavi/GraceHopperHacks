package jrJava.GraceHopperHacks;


import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.*;




public class Login implements ActionListener{
    private CardLayout cardLayout;
    private JFrame frame;
    private JPanel panel;
    private JTabbedPane tabbed;
    private JPanel login;
    private JButton[] buttons;
    private String[] pageNames = {"Student",  "Teacher"};
    private JPanel page1;
    private JScrollPane page2;
    private JFrame buttonsFrame;
    private JPanel buttonsPanel;

    public Login() {
        
        buttonsFrame = new JFrame("Control Frame");
        buttonsFrame.setBounds(850, 600, 100, 80);
        buttonsFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); 
        
        buttonsPanel = new JPanel();
        buttonsPanel.setBackground(Color.WHITE);
        buttonsFrame.add(buttonsPanel);
        
        buttons = new JButton[2];
        for(int i=0; i<buttons.length; i++) {
            buttons[i] = new JButton(pageNames[i]); 
            buttonsPanel.add(buttons[i]);
            buttons[i].addActionListener(this); 
        }
        
        buttonsFrame.pack();
        buttonsFrame.setVisible(true);
        
        try {
            Thread.sleep(10);
        } catch (InterruptedException e) { }
        
        buttons[1].requestFocus();
    }
    
    public void actionPerformed(ActionEvent e) {
        
        if(e.getSource()==buttons[0]) {
            new Student();
        }
        else if(e.getSource()==buttons[1]) {
            new Teacher();
            
        }
              
    }
     
    public static void main(String[] args) {
        new Login();
    }

}



