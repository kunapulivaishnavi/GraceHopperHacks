package jrJava.GraceHopperHacks;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;

public class ThankYou {

    private JButton button;
    private JFrame frame;
    static JPanel panel;
    private JTabbedPane tabbed;
    
   
    public ThankYou()  {
        
        
         
        frame = new JFrame("Thank You");
        frame.setBounds(100, 100, 500, 10);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        panel = new JPanel();
        GridLayout layout = new GridLayout(5,5);
        panel.setLayout(layout);
        panel.setBackground(Color.WHITE);
        panel.setLayout(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 20, 10)); 
        frame.add(panel);
        JLabel label = new JLabel("   Thank you for submitting. We will contact the people involved for more details.");
        panel.add(label);
        frame.setVisible(true);
       
        
    }
    
    public static void printIncidentToFile() throws IOException {
        System.out.println("From PrintIncidentToFile");
        String incident = Student.textField3.getText();
        PrintWriter out = PushToDataFile();
        BufferedReader f = new BufferedReader(new FileReader("jrJava\\GraceHopperHacks\\Data"));
        out.println(incident );  
        out.close();
        
    }
    
    public static PrintWriter PushToDataFile() throws IOException {
        
        PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter("jrJava\\GraceHopperHacks\\Data", true))); 
        return out;
        
    } 

        

    
  /*  public static void main(String[] args) {
        new ThankYou();
    }*/


   
    
        
        
    }

